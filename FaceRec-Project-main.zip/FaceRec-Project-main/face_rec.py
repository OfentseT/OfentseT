import face_recognition
import cv2

# Step 1: Load training images and create encodings
_face_encodings = []
_face_names = []

# Manually add training images
images = {
    "Andrew_Garfield": r"Images\Andrew_Garfield.webp",
    "Henry_Calvin": r"Images\Henry_Calvin.webp",
    "Hugh_Jackman": r"Images\Hugh_Jackman.webp",
    "Jamie_Foxx": r"Images\Jamie_Foxx.webp",
    "Kobe_Bryant": r"Images\Kobe_Bryant.webp",
    "Lebron_James": r"Images\Lebron_James.webp",
    "Megan_Foxx": r"Images\Megan_Foxx.webp",
    "Micheal_Jordan": r"Images\Micheal_Jordan.webp",
    "Micheal.B_Jordan": r"Images\Micheal.B_Jordan.webp",
    "RDJ": r"Images\RDJ.webp",
    "Rayan_Reynolds": r"Images\Rayan_Reynolds.webp",
    "Tobey_Maguire": r"Images\Tobey_Maguire.webp",
    "Tom_Holland": r"Images\Tom_Holland.webp"
}

for name, image_path in images.items():
    image = face_recognition.load_image_file(image_path)
    encoding = face_recognition.face_encodings(image)[0]  # Encode the face
    _face_encodings.append(encoding)
    _face_names.append(name)

# Step 2: Initialize the webcam
video_capture = cv2.VideoCapture(0)

print("Press 'q' to quit the program.")

while True:
    # Capture a single frame from the webcam
    ret, frame = video_capture.read()
    if not ret:
        break

    # Convert the frame to RGB (face_recognition works with RGB images)
    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    # Find face locations and encodings in the current frame
    face_locations = face_recognition.face_locations(rgb_frame)
    face_encodings = face_recognition.face_encodings(rgb_frame, face_locations)

    # Match each face to the known encodings
    for (top, right, bottom, left), face_encoding in zip(face_locations, face_encodings):
        matches = face_recognition.compare_faces(_face_encodings, face_encoding, tolerance=0.6)
        name = "Unknown"

        if True in matches:
            index = matches.index(True)
            name = _face_names[index]

        # Draw a rectangle around the face and label it with the name
        cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)
        cv2.putText(frame, name, (left, top - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (255, 255, 255), 2)

    # Display the video feed
    cv2.imshow("Face Recognition", frame)

    # Quit the program when 'q' is pressed
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release the webcam and close windows
video_capture.release()
cv2.destroyAllWindows()